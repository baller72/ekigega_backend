"""Initialisation du package commands."""
