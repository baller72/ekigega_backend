"""Initialisation du package management."""
